package com.util.impl.consoleTable.enums;

/**
 * Create by IntelliJ IDEA
 * cell alignment
 * @author chenlei
 * @dateTime 2018/12/11 9:53
 * @description Align
 */
public enum Align {

    LEFT,RIGHT,CENTER

}
